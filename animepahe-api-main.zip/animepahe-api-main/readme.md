# AnimepaheAPI

An unofficial REST API for [Animepahe](https://animepahe.pw/) that provides access to anime information, episodes, and streaming links with direct download support.

> **⚠️ IMPORTANT NOTICE: API MAYBE Temporarily Paused**  
> The API maybe temporarily paused due to suspiciously too many requests. My hosted version of this API is only for testing purposes. **You MUST host your own instance** to use the API.

## Features

- 🎯 Get currently airing anime
- 🔍 Search for specific anime
- 📋 Browse complete anime list
- 📺 Get anime details and episodes
- 🎬 Get streaming links with multiple resolutions
- 📥 Direct download links with quality options
- ⚡ Optimized parallel processing for faster responses
- 📱 Check encoding queue status
- 🐋 Redis support for improved performance
- 🛡️ Built-in DDoS protection bypass
- 🔄 Automatic cookie management

## Installation

```bash
git clone https://github.com/ElijahCodes12345/animepahe-api.git
cd animepahe-api
npm install
npx playwright install
copy .env.example .env
```

## Usage as a Library

You can also use this project as a **Node.js library** directly in your code without running a server.

**Installation:**
```bash
npm install github:ElijahCodes12345/animepahe-api
```

**Example Usage:**
```javascript
const animepahe = require('animepahe-api');

// Search for anime
const searchResults = await animepahe.search('title');
console.log(searchResults);

// Get anime info
const info = await animepahe.getInfo('title');
console.log(info);

// Get episode releases
const episodes = await animepahe.getReleases('title', 'episode_desc', 1);
console.log(episodes);

// Get streaming links (m3u8 URLs and download links)
const streamingData = await animepahe.getStreamingLinks('anime-session-id', 'episode-session-id');
console.log(streamingData.sources);   // HLS streams
console.log(streamingData.downloads); // Direct download links
```

## Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2FElijahCodes12345%2Fanimepahe-api)
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/ElijahCodes12345/animepahe-api)
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template/animepahe-api?referralCode=EgKNlg)
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/ElijahCodes12345/animepahe-api)

## Configuration

It works as it is but if you want you can create a `.env` file in the root directory:

```env
PORT=3000 # Optional
BASE_URL=https://animepahe.pw # Optional
USER_AGENT=  # Optional
COOKIES=     # Optional - for manual cookie management
USE_PROXY=false
IFRAME_BASE_URL=kwik.cx # Optional - Base URL for the video iframe (default: kwik.cx)
PROXIES=     # Optional - comma-separated proxy URLs
REDIS_URL=   # Optional - Redis connection URL for caching (e.g., redis://user:pass@host:port)
ALLOWED_ORIGINS= # Optional - CORS configuration (see below)
RATE_LIMIT_SECRET= # Only set this if you want rate limiting (see Rate Limiting section below)
RATE_LIMIT_MAX=100 # Max requests per window (when rate limiting is active)
RATE_LIMIT_WINDOW=900 # Time window in seconds (when rate limiting is active)
```

### CORS Configuration

By default, the API will allow requests from **all origins** (`*`). To restrict access to specific domains:

```env
# Allow all origins (default)
ALLOWED_ORIGINS=*

# Allow single origin
ALLOWED_ORIGINS=http://localhost:5173

# Allow multiple origins (comma-separated)
ALLOWED_ORIGINS=http://localhost:5173,https://mywebsite.com,https://another-site.com
```

### Redis Caching

The API supports Redis caching to improve performance and reduce load on the Animepahe servers. When `REDIS_URL` is provided, responses will be cached with the following durations:

- Queue status: 30 seconds
- Anime list: 1 hour
- Anime info: 1 day
- Play/stream info: 5 hours

You may edit these values as you see fit.

If `REDIS_URL` is not provided, the API will still work without caching.

## Rate Limiting

This API includes optional rate limiting that only activates when the `RATE_LIMIT_SECRET` environment variable is set. This allows you to add rate limiting to your own deployment (like your Vercel instance) without affecting other people who might host their own instances.

To enable rate limiting on your deployment:
1. Set a unique `RATE_LIMIT_SECRET` value (e.g., a random UUID)
2. Configure `RATE_LIMIT_MAX` (default: 100 requests per window)
3. Configure `RATE_LIMIT_WINDOW` in seconds (default: 900 seconds = 15 minutes)
4. Configure `REDIS_URL` for persistent rate limiting across server instances (recommended for production use)

**Note**: Rate limiting requires Redis to function properly. If `REDIS_URL` is not configured, rate limiting will be automatically disabled even if `RATE_LIMIT_SECRET` is set. This ensures that other deployments without Redis continue to work normally.

When rate limiting is active, the API will return HTTP 429 status codes when limits are exceeded, along with rate limit headers:
- `X-RateLimit-Limit`: Maximum requests per window
- `X-RateLimit-Remaining`: Requests remaining in current window
- `X-RateLimit-Reset`: Time when the current window resets

## API Endpoints

### Airing Anime
```
GET /api/airing
GET /api/airing?page=2
```

### Search Anime
```
GET /api/search?q=your_search_query
GET /api/search?q=your_search_query&page=2
```

### Anime List
```
GET /api/anime
GET /api/anime?tab=A
GET /api/anime/:tag1/:tag2
GET /api/anime/:tag1/:tag2?tab=D
```
tag1 being eg: genre, Theme, etc. tag2 being eg: action, adventure, historical etc.
Note: For tab use 'hash' instead of '#'

### Anime Information
```
GET /api/:session  # Get anime details using anime session ID
GET /api/:session/releases?sort=episode_desc&page=1  # Get episode list
```

### Streaming & Downloads
```
GET /api/play/:session?episodeId=example                # With downloads (default)
GET /api/play/:session?episodeId=example&downloads=false  # Without downloads (faster)
GET /api/play/download-links?url=https://pahe.win/XYZ # To only get one download link
```

> **Note:** 
> - `:session` is the anime's unique identifier
> - `episodeId` is the episode's unique identifier from the /releases endpoint
> - Use `downloads=false` for faster responses if you only need streaming links
> - **Important:** When downloading the direct `.mp4` video (the `download` URL), you MUST pass the provided `downloadPage` URL as the `Referer` header to avoid errors.

### Queue Status
```
GET /api/queue
```

## Error Handling

The API returns errors in this format:

```json
{
  "status": 503,
  "message": "Request failed"
}
```

## Technologies Used

- Node.js
- Express
- Playwright
- @sparticuz/chromium
- Cheerio
- Axios
- got-scraping
- cloudscraper (changed to above library)
- jsdom
- vm

## Acknowledgments

Special thanks to:
- [Pal-droid](https://github.com/Pal-droid) for assistance in improving the project's logic and features.
- All the developers whose libraries made this project possible.

## License

This project is licensed under the MIT License.

## Disclaimer

This project is not affiliated with or endorsed by Animepahe. It's an unofficial API created for educational purposes.

## Support

If you find this project helpful, please give it a ⭐️ on GitHub!